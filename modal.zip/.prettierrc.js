module.exports = {
  singleQuote: true,
  htmlWhitespaceSensitivity: 'ignore',
  trailingComma: 'none',
  arrowParens: 'always'
};
