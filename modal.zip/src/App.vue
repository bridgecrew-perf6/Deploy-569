<template>
  <router-view />
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import 'normalize.css';

export default defineComponent({
  name: 'App'
});
</script>

<style lang="scss">
.app {
}
</style>
